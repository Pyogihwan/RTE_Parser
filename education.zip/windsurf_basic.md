## 단축키
- Ctrl + B : 왼쪽 폴더 목록 열기/닫기
- Ctrl + J : 터미널 열기
- Ctrl + L : AI 채팅방 열기/닫기
- Ctrl + I : 특정 부분 수정